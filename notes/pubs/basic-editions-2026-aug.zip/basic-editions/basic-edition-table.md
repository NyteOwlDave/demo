
# BASIC Editions

| Folder    | Title                | Address |
|-----------|----------------------|------------------------------------------------|
| amiga     | Amiga Basic          | https://gotbasic.com/amiga.html                |
| anywhere  | Basic Anywhere       | https://basicanywheremachine.neocities.org/bam-ide  |
| apple     | Applesoft Basic      | https://gotbasic.com/apple.html                |
| atari     | Atari Basic          | https://eahumada.github.io/AtariOnline/basic/basic-mame.html    |
| b256      | Basic 256            | https://basic256.org                  |
| b3d       | 3D Basic             | https://threedbasic.wixsite.com/3d-basic          |
| b4x       | B4X                  | https://www.b4x.com                   |
| bazz      | Bazz Basic           | https://ekbass.github.io/BazzBasic             |
| bbc       | BBC Basic            | https://www.bbcbasic.co.uk/bbcsdl/index.html       |
| berry     | Berry Basic          | https://github.com/fritzone/berrybasic            |
| c64       | C64 Basic            | https://stigc.dk/c64/basic            |
| classic   | Classic Basic        | https://classicbasic.org              |
| free      | Free Basic           | https://freebasic.nethttps://freebasic.net         |
| fusion    | Basic Fusion         | https://basicfusion.org               |
| future    | Future Basic         | https://www.brilorsoftware.com/fb/pages/home.html   |
| gw        | GW Basic             | https://gotbasic.com/gw-basic.html             |
| pbasic    | PBASIC               | https://www.parallax.com/education/programming-languages/pbasic | 
| pc        | PC Basic             | https://robhagemans.github.io/pcbasic/doc/2.0  | 
| play      | Play Basic           | https://www.playbasic.com             | 
| pure      | Pure Basic           | https://www.purebasic.com             | 
| qb45      | QuickBasic 45        | https://vetusware.com/download/qb4.5%204.5/?id=5422 | 
| qb64      | QuickBasic 64        | https://qb64.com                      |
| qb64pe    | QuckBasic 64 Phoenix | https://qb64phoenix.com               |
| qbasic    | QBasic               | https://qbasic.com                    | 
| qbjs      | QuickBasic JS        | https://qbjs.org                      | 
| qbx       | QBX                  | https://github.com/logiclrd/QBX       | 
| sedai     | Sedai Basic          | https://github.com/camauri/SedaiBasic2         | 
| sega      | Sega Basic           | https://segaretro.org/BASIC_Level_III_A        | 
| spectrum  | Spectrum Basic       | https://github.com/ZXDunny            | 
| thoreau   | Thoreau Basic        | https://tarjan.itch.io/thoreaubasic            | 
| ti99      | TI-99 Basic          | https://sourceforge.net/projects/ti99basic     | 
| trs80     | TRS-80 Basic         | https://www.trs-80.org/level-2-basic.html      | 
| vb        | Visual Basic         | https://microsoft-visual-basic.en.softonic.com    |
| vbnet     | Visual Basic.Net     | https://gotbasic.com/vb.html          |
| vbscript  | VB Script            | https://en.softonic.com/downloads/vbscript        |
| vbsmall   | Small VB             | https://smallbasic-publicwebsite.azurewebsites.net |
| vintage   | Vintage Basic        | http://www.vintage-basic.net          |
| vision    | Vision Basic         | https://visionbasic.net               |
| webqb     | Web QB               | https://webqb.org                     |
| zx        | ZX Basic             | https://fuse-emulator.sourceforge.net |

